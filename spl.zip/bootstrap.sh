#!/usr/bin/env bash

apt-get -qq update
apt-get -q install -y g++ make gdb cmake git valgrind 